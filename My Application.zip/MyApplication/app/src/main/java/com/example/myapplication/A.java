package com.example.myapplication;

class A {

    public A(Float rat) {
        this.rat = rat;
    }

    Float rat;

    public Float getRat() {
        return rat;
    }

    public void setRat(Float rat) {
        this.rat = rat;
    }
}
